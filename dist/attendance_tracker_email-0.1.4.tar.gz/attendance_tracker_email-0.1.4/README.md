# Attendance Tracker

Tracks the attendance of participants in online events using their emails


### Next in the project
- [ ] #739 Create a chrome extension for the frontend
- [ ] Authentication to take attendance manually
- [ ] Track time attended
  